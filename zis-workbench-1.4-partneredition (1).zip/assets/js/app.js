// Initialise Vue instance
const vm = new Vue({
    el: '#app',
    vuetify: vuetify,
    highlightjs: hljsVuePlugin,
  
    /////////////////////////////////////////////////////////////////////////////
    // Data
    /////////////////////////////////////////////////////////////////////////////
  
    data: {
  

      // Validation rules (currently not used...)
      //
      rules: {
        required: value => !!value || 'Required.',
        number: value => !Number.isNaN(value),
        integrationName: value => {
          const pattern = /^[0-9A-Za-z_\-]+$/;
          return pattern.test(value) || 'Invalid integration name.'; 
        },
        email: value => {
          const pattern = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
          return pattern.test(value) || 'Invalid e-mail.' }
      },

      // TODO: Remove this extra layer??
      sharedData: {
 
        /*

        TODO:
        - Refactor into smaller & resuable components
        - Use a proper progress bar

        IDEAS:
        - Progress bar
        - Use another JSON editor/viewer:
          - https://github.com/egoist/vue-monaco
        - Use a flowchart plugin or something to render the flow in real-time?
        - Include this flow?
          - https://github.com/zendesk/quantum/blob/main/conversations_naming/bundle.json
        - Add new config fields on the fly (when doing edit of the flow)


        */

        // Flows 
        //
        flows: {

          grouping_problem_incidents: {
            name: "Automatic Grouping of Tickets into Problem & Incidents",
            description: "Demo flow to demonstrate how automatically group tickets into Problem and Incidents based on a common property on the ticket",
            howToUse: `
            Complete the following to prepare this flow:
            <ol>
            <li>Create a custom ticket field (text) that you will use to link the tickets. For example, a field called Listing ID, Product ID, Service ID, etc.</li>
            <li>Copy your custom ticket field ID to your clipboard.</li>
            <li>Create a ticket form that contains the Type field + your custom ticket field.</li>
            <li>In the ZIS app, paste the custom ticket field ID in the Configuration tab and click Save.</li>
            <li>In the ZIS app, toggle Enabled to enable the flow.</li>
            </ol>
            <br>
            To see this flow in action, do the following:
            <ol>
            <li>Create a ticket with the listing ID field filled in and submit as New.</li>
            <li>Create a new ticket with the same listing ID and submit as New.</li>
            <li>Re-open the created tickets. The first ticket should now automatically become a Problem, and the second one has become a Incident and is connected to the problem</li>
            </ol>
            <br>
            Note: The flow is using the Zendesk search API for checking for other tickets with the same listing ID. As it can take up to a few minutes for new tickets to be indexed for search, 
            you should wait 1-2 minutes before creating the second ticket (otherwise the logic might not be triggered).
            `,
            design: "flows/automatic_grouping_tickets_problem_incidents.png",
            sourceUrl: "flows/automatic_grouping_tickets_problem_incidents.json",
            jobSpecs: ["automatic_grouping_tickets_problem_incident"],
            eventSources: [
              "On Ticket Creation"
            ],
            configScope: "automatic-grouping-tickets-problem-incident-flow",
            configFields: {
              listingId_fieldId: {
                label: "Field Id for Listing Id",
                type: "number"
              }
            },
            examplePayloadUrl: "flows/create_ticket_event_payload.json" // TODO: Have the possibility to have placeholder to replace with a real ticket/user id
          },
          
          send_ticket_to_webhook: {
            name: "Transform & Send Ticket to Webhook",
            description: "Transforms and post ticket data to an external target on ticket create",
            howToUse: `
            Complete the following to prepare this flow:
            <ol>
            <li>Get a public non-secured webhook URL on <a href="https://webhook.site" target="_blank">https://webhook.site</a> for a mock webhook URL.</li>
            <li>Copy the webhook URL to your clipboard. Make sure to pick the correct URL (not the one with '/#!/' in the path).</li>
            <li>In the ZIS app, paste your webhook URL in the Configuration tab and click Save.</li>
            <li>In the ZIS app, toggle Enabled to enable the flow.</li>
            </ol>
            <br>
            To see this flow in action, do the following:
            <ol>
            <li>Create a ticket and submit.</li>
            <li>Go to the webhook provider or webhook.site, and verify that the custom ticket payload has arrived.</li>
            </ol>
            `,
            design: "flows/post_ticket_to_webhook.png",
            sourceUrl: "flows/post_ticket_to_webhook.json",
            jobSpecs: [ "post_ticket_to_webhook" ],
            eventSources: [
              "On Ticket Creation"
            ],
            configScope: "post-ticket-to-webhook",
            configFields: {
              webhookUrl: {
                label: "Webhook URL"
              }
            },
            examplePayloadUrl: "flows/create_ticket_event_payload.json",
            integrationLogos: {
              fromLogo: "img/zendesk.png",
              toLogo: "img/webhook.png"
            }
          },

          slack_links: {
            name: "Send Slack Notification on Ticket",
            description: "Send Slack notification when ticket is created or comment is added on a ticket",
            howToUse: `
            Complete the following to prepare this flow:
            <ol>
            <li>First of all you need to set up your own Slack app. Follow the instructions on <a href="https://developer.zendesk.com/documentation/integration-services/zis-tutorials/zendesk-app-admin-interface/zis-obtain-oauth-token/" target="_blank">Connect to Slack</a></li>
            <li>Follow the instructions through Add Redirect URL.</li>
            <li>Once you've added the Redirect URL, go to the Slack API page nav bar and scroll up to Settings > Basic Information.</li>
            <li>Scroll down to App Credentials and copy your Client ID and Client Secret.</li>
            <li>In the ZIS app, click on the Connections tab and paste your Client ID and Client Secret in the fields.</li>
            <li>Click to Connect to Slack and approve the integration to use your Slack workspace.</li>
            <li>In the ZIS app (in the Configuration tab), indicate the #channel (include the hashtag) of the Slack channel this should create a message in.</li>
            <li>Then toggle on 'Enabled'</li>
            <li>Add your Slack app to the channel that you configured above.</li>
            <li>Open channel settings in Slack and click on the 'Integrations'-tab.</li>
            <li>Click 'Add apps' and select the the app you created earlier.</li>
            </ol>
            <br>
            To see this flow in action, do the following:
            <ol>
            <li>Create a new ticket in Agent Workspace</li>
            <li>Go to your Slack workspace and selected channel. You should now see the created ticket in your channel.</li>
            <li>Add a comment on the created ticket</ali>
            <li>The added comment should now appear as a threaded message to the first Slack message</li>
            </ol>
            `,
            connections: [
              {
                description: "This flow requires an OAuth connection is created to Slack. To create a Slack connection you need provide client ID and client secret.",
                label: "Create Slack connection",
                name: "slack", 
                defaultScopes: "chat.postMessage",
                permissionScopes: "chat:write", 
                authUrl: "https://slack.com/oauth/v2/authorize",
                tokenUrl: "https://slack.com/api/oauth.v2.access",
                created: false,
                clientId: "",
                clientSecret: "",
              }
            ],
            design: "flows/send_slack_notification_on_ticket.png",
            sourceUrl: "flows/send_slack_notification_bundle.json",
            jobSpecs: [ "send-slack-notification-ticket-created", "send-slack-notification-comment-added"],
            eventSources: [
              "On Ticket Creation",
              "On Ticket Comment Added"
            ],
            configScope: "post-message-to-slack-on-ticket-creation", 
            configFields: {
              channel: {
                label: "Slack Channel"
              }
            },
            examplePayloadUrl: "flows/create_ticket_event_payload.json",
            integrationLogos: {
              fromLogo: "img/zendesk.png",
              toLogo: "img/slack.png"
            }
          },

          salesforce: {
            name: "Salesforce Contact Sync",
            description: "Create Sunshine profile & event when a contact in Salesforce is created",
            howToUse:  `
            This flow demonstrates how creation of Salesforce contacts can trigger creation of a Sunshine profiles.  
            To use this flow, you need to make sure you have enabled Sunshine profiles & events on your instance, 
            see <a href="https://support.zendesk.com/hc/en-us/articles/4408828663322-Adding-Sunshine-user-profiles-and-events-to-customer-context-in-a-ticket" target="_blank">Adding Sunshine user profiles and events to customer context in a ticket</a>.
            Make sure custom event with source 'salesforce' is enabled.
            <br><br>
            To see the flow in action, do the following:
            <ol>
            <li>Click on the 'Webhooks'-tab and click on the 'Fire Webhook'-button</li>
            <li>A popup will appear with an example payload. Modify the name ('FirstName', 'LastName') and email address ('Email') to control which user that will be created in Zendesk. Note if you issue the request several times, you might also need to modify the contact ID ('Id') to avoid conflicts in Zendesk.</li>
            <li>Click on the 'Send'-button. The webhook is triggered and the flow is executed</li>
            <li>Open an arbitrary ticket in Agent Workspace and add the new user as the requester</li>
            <li>Open the user profile and a new Salesforce profile should be available. In the 'Interactions'-section you should find an 'Salesforce contact created' event</li>
            </ol>
            `,
            design: "flows/create_sunshine_profile_at_salesforce_contact_creation.png",
            sourceUrl: "flows/create_sunshine_profile_at_salesforce_contact_creation.json",
            jobSpecs: [ "handle-contact-created-webhook" ],
            eventSources: [
              "On Contact Creation in Salesforce"
            ],
            configScope: null,
            configFields: {},
            inboundWebhook: {
              source_system: "salesforce",
              event_type: "AtContactCreation"
            },
            examplePayloadUrl: "flows/salesforce_contact.json",
            integrationLogos: {
              fromLogo: "img/salesforce.png",
              toLogo: "img/zendesk.png"
            }
          },


          extract_data_from_ticket_body: {
            name: "Extract Data from Ticket Body",
            description: "Extract data from ticket body into a ticket field at ticket creation using a regex expression",
            howToUse: `
            To setup the flow you need to do the following:
            <ol>
            <li>Go into Admin Center and select the ticket fields administration</li>
            <li>Find a field you want to use for this flow and copy the field ID</li>
            <li>Go the the configuration tab and paste the field ID into the 'Ticket Field ID' configuration</li>
            <li>Set a regex expression for the data you want to extract from the ticket body. By default there is a regex expression that looks for a value matching: 'ID: <VALUE>'</li>
            </ol>
            <br>
            Note: The flow expects a Regex expression with a capture, i.e. the part of the matching data that should be used as a value. In Regex this is done with a parenthesis, e.g. 'ID: (\w)*'
            (which uses '1234' if 'ID: 1234' is found in the ticket description).
            <br><br>
            To see the flow in action, do the following:
            <ol>
            <li>Create a new ticket using an extractable value in the body (for example 'ID: 12345')</li>
            <li>After the ticket has been created, verify that the field value now contains the extracted value (for example '12345')</li>
            </ol>
            `,
            design: "flows/extract_data_from_ticket_body.png",
            sourceUrl: "flows/extract_data_from_ticket_body.json",
            jobSpecs: [ "extract_data_from_ticket_body" ], 
            eventSources: [ "On Ticket Creation" ],
            configScope: "extract-data-from-ticket-body",
            configFields: {
              ticketFieldId: {
                label: "Ticket Field ID",
                type: "number"
              },
              regexExpression: {
                label: "Regex Expression",
                defaultValue: "ID:(\w*)"
              }
            },
            examplePayloadUrl: "flows/create_ticket_event_payload.json"
          },

          redact_ticket: {
            name: "Redact Tickets Automatically",
            description: "Redact sensisble information (social security numbers etc) automatically from tickets using a set of Regex expressions",
            howToUse: `
            To setup the flow you need to do the following:
            <ol>
            <li>Configure Regex expressions to use by adding them to the field 'Regex Expressions' under the 'Configuration' tab. To enter several expressions, you have to press return after each expression before entering the next one.</li>
            <li>Hit 'Save' to save the configuration in ZIS.</li>
            </ol>
            <br>
            Example of Regex expressions to use:
            <ul>
              <li>US social security number: <i>[0-8][0-9]{2}-[0-9]{2}-[0-9]{4}</i></li>
              <li>UK national insurance number (simplified): <i>[A-Z]{2}[0-9]{6}[A-D ]</i></li>
              <li>Swedish social security number: <i>\\d{6,8}[-|(\s)]{0,1}\\d{4}</i></li>
            </ul>
            Note: ZIS doesn't support (?!) notation (for example: '(?!000|666)').<br><br>
            To see the flow in action, do the following:
            <ol>
            <li>Create a new ticket or add a comment to existing ticket with sensible information (social security number for example) in the description/comment</li>
            <li>Verify that the information is redacted automatically</li>
            </ol>
            `,
            design: "flows/msar_handler.png",
            sourceUrl: "flows/redact_ticket.json",
            jobSpecs: [ "redact_ticket_when_comment_is_added" ], 
            eventSources: [ "On Comment Added" ],
            configScope: "redact-ticket",
            configFields: {
              regexExpressions: {
                label: "Regex Expressions",
                isList: true
              }
            },
            examplePayloadUrl: "flows/ticket_comment_added_payload.json"
          }
        },

        // App state data
        //
        mainTabs: 1,
        tabs: {},
        webhookDialogs: {},
        integrationName: "",
        useWithZisPlayground: false,
        showIntegrationNameDialog: false,
        showZendeskConnectionDialog: false,
        showFlows: false,
        flowAccordionStates: [],
        confirmDialog: {
          open: false,
          title: "Confirm"
        },
        connections: [],

        // Request new flow 
        //
        requestNewFlow: {
          enabled: false
        },
        // Create new flow 
        //
        newFlow: {
          enabled: false,
          fileUploadEnabled: false,
          fileLoading: false,
          tabs: {},
          connectionsEnabled: false,
          inboundWebhookEnabled: false,
          jobSpecs: [
            {
              name: "",
              eventSource: "support", 
              eventType: ""
            }
          ],
          config: {
            enabled: false,
            fields: [
              {
                name: "",
                label: "",
                defaultValue: null,
                type: "text",
                isList: false
              }
            ]
          },
          inboundWebhook: 
          {
            sourceSystem: "",
            eventType: ""
          },
          connections: [
            {    
              name: "",       
              defaultScopes: "",
              permissionScopes: "", 
              authUrl: "",
              tokenUrl: ""
            }
          ]
        },
  
      },

      fieldTypes: [
        "text",
        "number",
        "boolean"
      ],
  
      supportEventTypes: [

        // TODO: Have a more user friendly name of the event source

        // Ticket Events
        //
        "---- TICKET EVENTS --------",
        "ticket.AgentAssignmentChanged",
        "ticket.AttachmentLinkedToComment",
        "ticket.AttachmentRedactedFromComment",
        "ticket.BrandChanged",
        "ticket.CommentAdded",
        "ticket.CommentMadePrivate",
        "ticket.CommentRedacted",
        "ticket.CustomFieldChanged",
        "ticket.DescriptionChanged",
        "ticket.CcsChanged",
        "ticket.ExternalIdChanged",
        "ticket.FollowersChanged",
        "ticket.TicketFormChanged",
        "ticket.GroupAssignmentChanged",
        "ticket.OrganizationChanged",
        "ticket.PriorityChanged",
        "ticket.ProblemLinkChanged",
        "ticket.RequesterChanged",
        "ticket.StatusChanged",
        "ticket.SubjectChanged",
        "ticket.SubmitterChanged",
        "ticket.TagsChanged",
        "ticket.TaskDueAtChanged",
        "ticket.TicketCreated",
        "ticket.MarkedAsSpam",
        "ticket.TicketMerged",
        "ticket.TicketPermanentlyDeleted",
        "ticket.TicketSoftDeleted",
        "ticket.TicketTypeChanged",
        "ticket.TicketUndeleted",

        // User Events
        //
        "---- USER EVENTS --------",
        "user.UserIsActiveChanged",
        "user.UserAliasChanged",
        "user.CustomFieldChanged",
        "user.CustomRoleChanged",
        "user.UserDefaultGroupChanged",
        "user.UserDetailsChanged",
        "user.ExternalIdChanged",
        "user.UserGroupAdded",
        "user.UserGroupRemoved",
        "user.UserIdentityChanged",
        "user.UserIdentityCreated",
        "user.UserIdentityRemoved",
        "user.LastLoginChanged",
        "user.LocaleChanged",
        "user.UserNameChanged",
        "user.UserNotesChanged",
        "user.OnlyPrivateCommentsChanged",
        "user.UserOrganizationAdded",
        "user.UserOrganizationRemoved",
        "user.UserPhotoChanged",
        "user.UserRoleChanged",
        "user.TagsChanged",
        "user.TimeZoneChanged",
        "user.UserCreated",
        "user.UserMerged",

        // Organization Events
        //
        "---- ORGANIZATION EVENTS --------",
        "organization.CustomFieldChanged",
        "organization.ExternalIdChanged",
        "organization.OrganizationCreated",
        "organization.TagsChanged"     
      ],

      sunshineEventTypes: [
        // Custom Object Events
        //
        "---- CUSTOM OBJECT EVENTS --------",
        "customobject.CustomObjectChanged",
        "customobject.CustomObjectDeleted",

        // Activity Events
        //
        "---- ACTIVITY EVENTS --------",
        "activity.UserActivityCreated"
      ],

      loader: {
        active: false,
        opacity: 1
      }
    },
  
    /////////////////////////////////////////////////////////////////////////////
    // Computed
    /////////////////////////////////////////////////////////////////////////////
  
    computed: {

    },
  
    /////////////////////////////////////////////////////////////////////////////
    // Methods
    /////////////////////////////////////////////////////////////////////////////
  
    methods: {

      toggleIntegrationName() {
        if (this.sharedData.useWithZisPlayground) {
          this.sharedData.integrationName = this.sharedData.playgroundIntegrationName;
        } else {
          this.sharedData.integrationName = this.sharedData.suggestedIntegrationName;
        }
      },

      saveIntegrationName() {   
        console.log("Creating ZIS integration...");
        createIntegration(this.sharedData.integrationName, "ZIS Integration for demo flows").then(integration => {
          console.log("Integration created successfully", integration);

          if (this.sharedData.metadata.appId != 0) {
          updateAppSetting(this.sharedData.metadata.appId, "integration_name", this.sharedData.integrationName);
          }

          var appConfig = {
            config: {
              useWithZisPlayground: this.sharedData.useWithZisPlayground,
              zendeskConnectionInstalled: false,
              flows: {}
            },
            scope: "zis-workbench"
          };

          createConfig(this.sharedData.integrationName, appConfig).then(() => {
            console.log("Config created successfully");
          })
          .catch(error => {
              console.log("Config already exists. Updating it instead");
              updateConfig(this.sharedData.integrationName, "zis-workbench", appConfig).then(() => {
                console.log("Config updated");
              });
          })
          .finally(() => {
            this.sharedData.appConfig = appConfig;
            this.sharedData.showIntegrationNameDialog = false;
            this.sharedData.showZendeskConnectionDialog = true;  
          });

        })
        
      },

      connectToZendesk() {
        startOAuthFlow(this.sharedData.integrationName, "zendesk", "zendesk", this.sharedData.subdomain, 
                       "read write", this.connectToZendeskDone);
      },

      connectToZendeskDone() {
        console.log("Connect to Zendesk completed successfully.");
        this.sharedData.showZendeskConnectionDialog = false;

        this.sharedData.appConfig.config.zendeskConnectionInstalled = true;
        updateConfig(this.sharedData.integrationName, "zis-workbench", this.sharedData.appConfig);
        this.sharedData.showFlows = true;
        this.initFlows();
      },

      // TODO: How to create a connection to another ZD instance???


      createConnection(connectionConfig) {

        console.log("Creating connection to: " + connectionConfig.name);

        var authUrl;
        var tokenUrl;
        if (connectionConfig.isZendeskConnection) {
          console.log("Creating an additional Zendesk connection...");
          authUrl = connectionConfig.authUrl.replaceAll("%INSTANCE_NAME%", connectionConfig.zendeskInstanceId);
          tokenUrl = connectionConfig.tokenUrl.replaceAll("%INSTANCE_NAME%", connectionConfig.zendeskInstanceId);   
          console.log("Using following URLs:", authUrl, tokenUrl);     
        } else {
          authUrl = connectionConfig.authUrl;
          tokenUrl = connectionConfig.tokenUrl;
        }
     
        createOAuthClient(this.sharedData.integrationName, connectionConfig.name, connectionConfig.clientId, connectionConfig.clientSecret,
                          authUrl, tokenUrl, connectionConfig.defaultScopes).then(() => {
          startOAuthFlow(this.sharedData.integrationName, connectionConfig.name, connectionConfig.name, this.sharedData.subdomain,
                         connectionConfig.permissionScopes, this.createConnectionDone, {connectionConfig: connectionConfig});
        });
        
      },

      createConnectionDone(args) {
        console.log(`Flow connection completed successfully.`);
        console.log("Flow Connection", args.connectionConfig);
        notifyTemp(`Connection to ${args.connectionConfig.name} has been created`);

        // Refresh connection list
        //
        getConnections(this.sharedData.integrationName).then(result => {
          console.log("Available connections", result.connections);
          this.sharedData.connections = result.connections;
          args.connectionConfig.created = true;
          for (const connection of this.sharedData.connections) {
            if (connection.name == args.connectionConfig.name) {
              args.connectionConfig.details = connection;
            }
          }
        });
      },

      openConfirmDialog(message, confirmAction) {
        this.sharedData.confirmDialog.message = message;
        this.sharedData.confirmDialog.open = true;
        this.sharedData.confirmDialog.confirmAction = confirmAction;
      },

      confirmAction() {
        this.sharedData.confirmDialog.open = false;
        this.sharedData.confirmDialog.confirmAction();
      },

      installFlow(flowId, flow, postInstallCallback) {

        // Install flow via ZIS bundle
        //
        console.log("Installing flow: " + flow.name);

        installFlow(this.sharedData.integrationName, flow.source).then(() => {

          if (flow.sourceUrl) {
          // Read source 
          //
          fetch(flow.sourceUrl)
            .then(result => result.text())
            .then(jsonStr => {
              flow.source = jsonStr.replaceAll('%INTEGRATION_NAME%', this.sharedData.integrationName);
              flow.json = JSON.parse(flow.source);
            });
          }

          // Create flow data
          //
          console.log("Creating flow data for flow: " + flowId);
          this.sharedData.appConfig.config.flows[flowId] = {
            enabled: false
          };

          if (flow.createdFromScratch) {
            console.log("Is a new flow created from scratch using the following input:", flow);
            var flowRecord = this.sharedData.appConfig.config.flows[flowId];
            flowRecord.flowData = {
              name: flow.name, 
              description: flow.description, 
              jobSpecs: flow.jobSpecs,
              eventSources: flow.eventSources,
              configScope: flow.configScope,
              configFields: flow.configFields,
              inboundWebhook: flow.inboundWebhook ? Object.assign({}, flow.inboundWebhook) : undefined,
              connections: flow.connections ? copyObjectArray(flow.connections) : undefined
            };
            flowRecord.source = flow.source;  
            console.log("Flow Data", flowRecord.flowData);        
          }
          
          // If flow is triggered by an inbound webhook -> create the webhook & store UUID in flow config
          //
          if (flow.inboundWebhook) {
            flow.inboundWebhook.details = {};
            console.log("Create inbound webhook for flow: " + flowId, flow.inboundWebhook);
            createInboundWebhook(this.sharedData.integrationName, flow.inboundWebhook, this.sharedData.zendeskAccessToken).then(result => {
              // Get UUID and store it in the flow config
              //
              flow.inboundWebhook.uuid = result.uuid;
              console.log("Webhook UUID: " + flow.inboundWebhook.uuid);

              getInboundWebhook(this.sharedData.integrationName, flow.inboundWebhook.uuid, this.sharedData.zendeskAccessToken).then(result => {
                flow.inboundWebhook.details = result;
              });

              // TODO: Add support for several webhooks - but how likely is it that you need several webhooks into one single flow??
              this.sharedData.appConfig.config.flows[flowId].webhook_uuid = flow.inboundWebhook.uuid;
              updateConfig(this.sharedData.integrationName, "zis-workbench", this.sharedData.appConfig);
            });
          } else {
            updateConfig(this.sharedData.integrationName, "zis-workbench", this.sharedData.appConfig);
          }

          // Check if required connections is set up
          //
          if (flow.connections) {
            for (const connectionConfig of flow.connections) {
              for (const connection of this.sharedData.connections) {
                if (connection.name == connectionConfig.name) {
                  console.log(`Flow required connection ${connectionConfig.name} is set up`);
                  connectionConfig.created = true;
                  connectionConfig.details = connection;
                }
              }
            }
          }
          
          // Create config for the integration
          //        
          if (flow.configScope) {
            console.log("Setup flow configuration with default values...");
            var flowConfig = {
              config: {},
              scope: flow.configScope
            };
            
            for (const [fieldId, field] of Object.entries(flow.configFields)) {
              if (field.defaultValue) {
                flowConfig.config[fieldId] = field.defaultValue;
              }
            }
            createConfig(this.sharedData.integrationName, flowConfig).then(() => {             
            }).catch(err => {
              // TODO: Handle the scenario when config already exists
              console.log("Error when creating flow configuration", err);
            }).finally(() => {
              this.loadConfiguration(flow);
              notifyTemp("Flow installed");
              flow.installed = true;
              this.$forceUpdate();
              if (postInstallCallback) {
                postInstallCallback();
              }
            });
            
          } else {
            // Flow does not have any config
            //
            notifyTemp("Flow installed");
            flow.installed = true;
            this.$forceUpdate();
          } 

          if (flow.examplePayloadUrl) {
            fetch(flow.examplePayloadUrl)
                .then(result => result.text())
                .then(jsonText => {
                  flow.examplePayload = jsonText;
                });
          }
            
        })
        .catch(err => {
          console.log("Error when installing flow", err);
          notifyErrorTemp("Could not install flow: " + err);
        });
      
      },

      deployFlow(flow) {
        installFlow(this.sharedData.integrationName, flow.source).then(() => {
          notifyTemp("Flow Changes Deployed");
        });
      },

      uninstallFlow(flowId, flow) {

        var app = this;
        this.openConfirmDialog(`Are you sure you want to uninstall the '${flow.name}' flow?`, function() {
              
          // Closes all accordions
          //
          app.sharedData.flowAccordionStates = [];

          // Disable flow by uninstalling job specification
          //
          if (flow.enabled) {
            flow.enabled = false;
            console.log("Disabling flow...")
            app.toggleFlow(flowId, flow);
          }

          // The actual flow definition can't be uninstalled unfortunately...

          // Delete flow data in the app config
          //
          console.log("Deleting flow data in app config...")
          delete app.sharedData.appConfig.config.flows[flowId];
          updateConfig(app.sharedData.integrationName, "zis-workbench", app.sharedData.appConfig).then(() => {
            flow.installed = false;
            notifyTemp("Flow uninstalled");
            app.$forceUpdate();
          });

        });

      },

      regenerateInboundWebhook(flowId, flow) {
        createInboundWebhook(this.sharedData.integrationName, flow.inboundWebhook, this.sharedData.zendeskAccessToken).then(result => {
          // Get UUID and store it in the flow config
          //
          flow.inboundWebhook.uuid = result.uuid;
          console.log("Webhook UUID: " + flow.inboundWebhook.uuid);

          getInboundWebhook(this.sharedData.integrationName, flow.inboundWebhook.uuid, this.sharedData.zendeskAccessToken).then(result => {
            flow.inboundWebhook.details = result;
          });

          // TODO: Add support for several webhooks - but how likely is it that you need several webhooks into one single flow??
          this.sharedData.appConfig.config.flows[flowId].webhook_uuid = flow.inboundWebhook.uuid;
          updateConfig(this.sharedData.integrationName, "zis-workbench", this.sharedData.appConfig);
          notifyTemp("Inbound Webhook regenerated");
          this.$forceUpdate();
        });
      },

      saveConfig(flow) {
        var flowConfig = {
          config: {}
        };

        for (const [configId, configValue] of Object.entries(flow.configFields)) {
          var value = null;
          if (configValue.type=="number") {
            if (configValue.isList) {
              value = [];
              for (const listItem of configValue.value) {
                value.push(Number(listItem));
              }
            } else if (!isEmpty(configValue.value)) {
              value = Number(configValue.value);
            }
          } else if (configValue.isList || !configValue.isList && !isEmpty(configValue.value)) {
            value = configValue.value
          }
          
          flowConfig.config[configId] = value; 
        }
        console.log("Saving config", flowConfig);
        updateConfig(this.sharedData.integrationName, flow.configScope, flowConfig);
        notifyTemp("Configuration updated.");
      },

      toggleFlow(flowId, flow) {
        this.sharedData.appConfig.config.flows[flowId].enabled = flow.enabled;
        updateConfig(this.sharedData.integrationName, "zis-workbench", this.sharedData.appConfig);
        if (flow.enabled) {
          for (const jobSpec of flow.jobSpecs) {
            console.log("Installing job spec: " + jobSpec);       
            installJobSpec(this.sharedData.integrationName, jobSpec);
          }
        } else {
          for (const jobSpec of flow.jobSpecs) {
            console.log("Uninstalling job spec: " + jobSpec);
            uninstallJobSpec(this.sharedData.integrationName, jobSpec);
          }
        }     
      },

      initFlows : async function() {

        console.log("Initializing flows...");

        // Initialize state fields
        //
        for (const [flowId, flow] of Object.entries(this.sharedData.flows)) {
          flow.tab = null;
          flow.installed = false;
          flow.activeTab = 0;
          flow.examplePayload = "";
          flow.isRecipe = true;
        }

        // Get all bundled flow source JSON definitions
        //       
        Promise.all(Object.entries(this.sharedData.flows).map( async ([flowId,flow]) => {
          return fetch(flow.sourceUrl)
                  .then(result => result.text())
                  .then(jsonStr => {
                    flow.source = jsonStr.replaceAll('%INTEGRATION_NAME%', this.sharedData.integrationName);
                    flow.json = JSON.parse(flow.source);
                  });
        })).then(() => {
                 
          var flowsInstalled = Object.keys(this.sharedData.appConfig.config.flows).length > 0;
          console.log("Flow installed: " + flowsInstalled);
          for (const [flowId, flowRecord] of Object.entries(this.sharedData.appConfig.config.flows)) {
            console.log("Flow ID: " + flowId);
            console.log(flowRecord);
            var flow = this.sharedData.flows[flowId];

            // If not a pre-installed flow
            //
            if (!flow) {
              flow = JSON.parse(JSON.stringify(flowRecord.flowData)); //Object.assign({}, flowRecord.flowData);
              this.sharedData.flows[flowId] = flow;
            }
            flow.enabled = flowRecord.enabled;
            flow.installed = true;

            // If source has been modified in ZIS Playground
            //
            if (flowRecord.source) {
              flow.source = flowRecord.source;
              flow.json = JSON.parse(flow.source);
            }
          
            if (flow.connections) {

              for (const connectionConfig of flow.connections) {
                // Check if required connection is set up
                //
                for (const connection of this.sharedData.connections) {
                  if (connection.name == connectionConfig.name) {
                    console.log(`Flow required connection ${connectionConfig.name} is set up`);
                    connectionConfig.created = true;
                    connectionConfig.details = connection;
                  }
                }
              }
            }

            if (flow.inboundWebhook) {
              flow.inboundWebhook.uuid = flowRecord.webhook_uuid;
              flow.inboundWebhook.details = {};
              flow.inboundWebhook.url = "";
            }
                        
          }

          // Get Zendesk access token used by ZIS to be able to create webhooks etc
          //
          getZendeskAccessToken(this.sharedData.integrationName).then(accessToken => {
            this.sharedData.zendeskAccessToken = accessToken;

            // Load webhook details
            //
            for (const [flowId, flow] of Object.entries(this.sharedData.flows)) {
              if (flow.installed && flow.inboundWebhook) {
                console.log("Getting inbound webhook details for flow: " + flowId);
                getInboundWebhook(this.sharedData.integrationName, flow.inboundWebhook.uuid, this.sharedData.zendeskAccessToken)
                  .then(webhook => {
                    flow.inboundWebhook.details = webhook;
                    flow.inboundWebhook.url = `https://${this.sharedData.subdomain}.zendesk.com${flow.inboundWebhook.details.path}`;
                  });
              }
            }
          })

          for (const [flowId, flow] of Object.entries(this.sharedData.flows)) {
            if (flow.installed && flow.examplePayloadUrl) {
              console.log("Fetching example payload for flow: " + flowId);
              fetch(flow.examplePayloadUrl)
                  .then(result => result.text())
                  .then(jsonText => {
                    flow.examplePayload = jsonText;
                  });
            }
          }

          this.loadConfigurations();
          this.$forceUpdate();
          

        });
      
      },

      loadConfigurations: async function() {
        console.log("Loading configurations...")
        for (const [flowId, flow] of Object.entries(this.sharedData.flows)) {
          if (flow.installed) {
            this.loadConfiguration(flow);
          }
        }
      },

      loadConfiguration(flow) {
        if (flow.configScope != null) {
          console.log("Loading config scope: " + flow.configScope);
          loadConfig(this.sharedData.integrationName, flow.configScope)
          .then(result => {
            var loadedConfig = result.configs[0].config;
            if (loadedConfig) {
              for (const [fieldId, field] of Object.entries(flow.configFields)) {
                var value = loadedConfig[fieldId];
                if (value) {
                  field.value = value;
                } else {
                  field.value = null;
                }
              }
            }
          });
        }
      },

      fireInboundWebhook(inboundWebhook, payload) {
        fireInboundWebhook(inboundWebhook.details.path, inboundWebhook.details.username, inboundWebhook.details.password, payload)
        .then(response => {
          notifyTemp("Inbound webhook called successfully.");
        })
        .catch(err => {
          notifyTemp(`Error: ${err.responseText}`);
        });
      },

      editInPlayground(flow) {

        var flowDef = null;
        var actions = {};
        for (const [resourceId, resource] of Object.entries(flow.json.resources)) {
            if (resource.type == "ZIS::Flow") {
              flowDef = resource.properties.definition;
            } else if (resource.type != "ZIS::JobSpec") {
              actions[resourceId] = resource;
            }
        }

        // TODO: Add support for template placeholder here, like %TICKETID%, "%USERID%", %CURRENTDATE%

        console.log("Flow Definition", flowDef);
        console.log("Actions", actions);

        if (flowDef) {
          loadConfig(this.sharedData.integrationName, "workspace:playground").then(result => {
            var config = result.configs[0].config;           
            if (config) {
              config.flow = JSON.stringify(flowDef, null, 2);
              config.actions = JSON.stringify(actions, null, 2);
              if (flow.examplePayload) {
                config.input = flow.examplePayload;
              }
              updateConfig(this.sharedData.integrationName, "workspace:playground", {config: config} ).then(() => {
                window.open(`https://${this.sharedData.subdomain}.zendesk.com/agent/apps/zis-playground`);
              });
            }        
          });
        }  

      },

      getChangesFromPlayground(flowId, flow) {

        loadConfig(this.sharedData.integrationName, "workspace:playground").then(result => {
          var config = result.configs[0].config;           
          if (config) {

            var flowResources = {};

            // Get updated actions
            // 
            var actions = JSON.parse(config.actions);
            for (const [actionId, action] of Object.entries(actions)) {
              flowResources[actionId] = action;
            }

            // Get updated flow definition
            //
            var updatedFlowDef = JSON.parse(config.flow);

            // Get existing flow definition
            //
            for (const [resourceId, resource] of Object.entries(flow.json.resources)) {
              if (resource.type == "ZIS::Flow") {
                resource.properties.definition = updatedFlowDef;
                flowResources[resourceId] = resource;
              }
            }

            // Extract job specs
            //
            for (const [resourceId, resource] of Object.entries(flow.json.resources)) {
              if (resource.type == "ZIS::JobSpec") {
                flowResources[resourceId] = resource;
              }
            }

            // Update flow source
            //
            flow.json.resources = flowResources;
            flow.source = JSON.stringify(flow.json, null, 2);

            // Store updated config in the configuration
            //
            var flowRecord = this.sharedData.appConfig.config.flows[flowId];
            if (flowRecord) {
              flowRecord.source = flow.source;
              updateConfig(this.sharedData.integrationName, "zis-workbench", this.sharedData.appConfig);
              this.$forceUpdate();
            }
          }
        });
      },

      exportFlow(flow) {
        
        // Create JSON filename from the Flow name
        //
        var filename = flow.name.toLowerCase().replaceAll(" ", "_") + ".json";

        // Create an environment agnostic version of the flow definition
        //
        var flowSource = flow.source.replaceAll(this.sharedData.integrationName, "%INTEGRATION_NAME%");

        // Piggyback configuration details in the flow definition (config scope and config fields)
        //       
        if (flow.configScope || flow.inboundWebhook || flow.connections) {
          var json = JSON.parse(flowSource);
          if (flow.configScope) {         
            json.zis_config_scope = flow.configScope;
            json.zis_config_fields = {};
            for (const [configId, configField] of Object.entries(flow.configFields)) {
              json.zis_config_fields[configId] = {
                label: configField.label,
                type: configField.type ? configField.type : "text",
                isList: configField.isList
              }
              if (configField.defaultValue) {
                json.zis_config_fields[configId].defaultValue = configField.defaultValue;
              }
            }
          }
          if(flow.inboundWebhook) {
            json.zis_inbound_webhook = {
              source_system: flow.inboundWebhook.source_system,
              event_type: flow.inboundWebhook.event_type
            };
          }
          if (flow.connections) {
            json.zis_connections = [];
            for (const connection of flow.connections) {
              json.zis_connections.push({
                name: connection.name,     
                defaultScopes: connection.defaultScopes,
                permissionScopes: connection.permissionScopes, 
                authUrl: connection.authUrl,
                tokenUrl: connection.tokenUrl
              });
            }
          }
          flowSource = JSON.stringify(json, null, 2);
        }
      
        downloadFile(flowSource, filename, "application/json");
      },

      createNewFlow() {

        var flow = this.sharedData.newFlow;

        console.log("Creating a new flow: " + flow.name);
        console.log("Using uploaded flow source", flow.flowSource);

        if (!flow.flowSource) {

          console.log("Generating flow JSON...");

          var flowSource = {
            name: flow.name, 
            description: flow.description, 
            zis_template_version: "2019-10-14",
            resources: {          
            },
          };

          var flowDef = {
            type: "ZIS::Flow",
            properties: {
              name: flow.flowName,
              definition: {
                StartAt: "",
              }
            }
          };

          if (flow.config.enabled) {

            // TODO: Use flow templates here??
            flowDef.properties.definition.States = {
              LoadConfig: {
                Type: "Action",
                ActionName: "zis:common:action:LoadConfig",
                Parameters: {
                  scope: flow.configScope
                },
                ResultPath: "$.model.config",
                Next: "Done"
              },
              Done: {
                Type: "Succeed"
              }
            };
            flowDef.properties.definition.StartAt = "LoadConfig";
          }
          else {
            flowDef.properties.definition.States = {
              Done: {
                Type: "Succeed"
              }
            };
            flowDef.properties.definition.StartAt = "Done";
          }

          flowSource.resources["flow_" +flow.flowName] = flowDef; 
          
          for (const jobSpecConfig of flow.jobSpecs) {          
            var jobSpec = {
              type: "ZIS::JobSpec",
              properties: {
                name: jobSpecConfig.name,
                event_source: jobSpecConfig.eventSource,
                event_type: jobSpecConfig.eventType,
                flow_name: "zis:" + this.sharedData.integrationName + ":flow:" + flow.flowName
              }
            };
            flowSource.resources["jobspec_" + jobSpecConfig.name] = jobSpec;
          }

          flow.flowSource = flowSource;
        } 

        var flowData = {
          name: flow.name,
          description: flow.description,
          installed: true,
          enabled: false,
          howToUse: null,
          design: null,
          source: JSON.stringify(flow.flowSource, null, 2),
          json: flow.flowSource,
          jobSpecs: [],
          eventSources: [],
          examplePayloadUrl: null,
          createdFromScratch: true
        };

        for (const jobSpecConfig of flow.jobSpecs) {
          flowData.jobSpecs.push(jobSpecConfig.name);
          flowData.eventSources.push(formatEventType(jobSpecConfig.eventType))
        }

        if (flow.inboundWebhookEnabled) {
          flowData.inboundWebhook = {
            source_system: flow.inboundWebhook.sourceSystem,
            event_type: flow.inboundWebhook.eventType
          };
        }

        if (flow.connectionsEnabled) {
          flowData.connections = [];
          for (const connection of flow.connections) {
            if (!connection.label) {
              connection.label = "Create " + capitalizeFirstLetter(connection.name) + " Connection";
            }
            flowData.connections.push(connection);
          }
        }

        if (flow.config.enabled) {
          flowData.configScope = flow.configScope;
          flowData.configFields = {};

          for (const field of flow.config.fields) {
            flowData.configFields[field.name] = {
              label: field.label,
              type: field.type,
              defaultValue: field.defaultValue,
              isList: field.isList
            }
          }
        }
        
        this.sharedData.flows[flow.flowName] = flowData;
        this.sharedData.newFlow.enabled = false;
        var app = this;
        this.installFlow(flow.flowName, flowData, function() {
          var flowIndex = Object.keys(app.sharedData.flows).filter(f => app.sharedData.flows[f].installed).length-1;
          app.sharedData.flowAccordionStates = [flowIndex];
        });

        console.log("Created Initial ZIS Flow:", flowData.source);

      },

      clearNewFormDialog(fileUploadEnabled) {
        this.sharedData.newFlow.fileUploadEnabled = fileUploadEnabled;
        this.sharedData.newFlow.name = "";
        this.sharedData.newFlow.description = "";
        this.sharedData.newFlow.jsonFile = null;
        this.sharedData.newFlow.flowSource = null;
        this.sharedData.newFlow.jobSpecs = [];
        this.addNewJobSpec();
        this.sharedData.newFlow.config.enabled = false; 
        this.sharedData.newFlow.config.fields = [];
        this.addNewConfigField();
        this.sharedData.newFlow.connections = [];
        this.addNewConnection();

        this.sharedData.newFlow.inboundWebhook.sourceSystem = "";
        this.sharedData.newFlow.inboundWebhook.eventType = "";

        this.sharedData.newFlow.connectionsEnabled = false;
        this.sharedData.newFlow.inboundWebhookEnabled = false;

        // Set start screen to the general tab
        // 
        this.sharedData.newFlow.tabs = 0;
      },

      onFlowNameChange(event)  {
        var name = event.target.value;
        this.sharedData.newFlow.flowName = name.toLowerCase().replaceAll(" ", "_");

        // TODO: Do this only when leaving the name field instead
        //if (this.sharedData.newFlow.jobSpecs[0].name == "") {
          this.sharedData.newFlow.jobSpecs[0].name = this.sharedData.newFlow.flowName;
        //}
        //if (this.sharedData.newFlow.configScope == "") {
          this.sharedData.newFlow.configScope = name.toLowerCase().replaceAll(" ", "-");
        //}
      },

      onFlowFileUpload(event) {
        if (event.target.files && event.target.files.length > 0) {
          var flow = this.sharedData.newFlow;
          flow.fileLoading = true;
          var flowFile = event.target.files[0];
          var fileReader = new FileReader();
          var integrationName = this.sharedData.integrationName;
          fileReader.onload = function(event) {
            var jsonText = event.target.result;
            jsonText = jsonText.replaceAll('%INTEGRATION_NAME%', integrationName);
            try {
              flowSource = JSON.parse(jsonText);
              if (flowSource.zis_template_version != "2019-10-14") {
                notifyTemp("Invalid format of JSON file!");
              } else {
                flow.flowSource = flowSource;
                flow.name = flowSource.name;
                flow.description = flowSource.description;
                flow.flowName = flow.name.toLowerCase().replaceAll(" ", "_");

                // Extract job specifications
                //
                flow.jobSpecs = [];
                for (const [resourceId, resource] of Object.entries(flowSource.resources)) {
                 if (resource.type == "ZIS::JobSpec") {
                    flow.jobSpecs.push({
                      name: resource.properties.name,
                      eventSource: resource.properties.event_source,
                      eventType: resource.properties.event_type
                    });
                  }
                }
      
                // Extract configuration scope & fields (if available)
                // This is using custom JSON fields only used by the ZIS Workbench
                //
                if (flowSource.zis_config_scope) {
                  flow.config.enabled = true;
                  flow.configScope = flowSource.zis_config_scope;
                  if (flowSource.zis_config_fields) {
                    flow.config.fields = [];
                    for (const [configId, configField] of Object.entries(flowSource.zis_config_fields)) {
                      flow.config.fields.push({
                        name: configId,
                        label: configField.label,
                        defaultValue: configField.defaultValue,
                        type: configField.type ? configField.type : "text",
                        isList: configField.isList
                      })
                    }
                  }
                }
                
                // Extract inbound webhook definition (if available)
                //
                if (flowSource.zis_inbound_webhook) {
                  flow.inboundWebhookEnabled = true;
                  flow.inboundWebhook.sourceSystem = flowSource.zis_inbound_webhook.source_system;
                  flow.inboundWebhook.eventType = flowSource.zis_inbound_webhook.event_type;
                }

                // Extract connection definitions
                //
                if (flowSource.zis_connections) {
                  flow.connectionsEnabled = true;
                  flow.connections = flowSource.zis_connections;
                }
                
              }
            }
            catch (e) {
              console.log("Could not parse JSON file", e);
              notifyTemp("Could not parse ZIS flow JSON file!");
            }


            flow.fileLoading = false;
          };
          fileReader.readAsText(flowFile);
        }
      },

      addNewConfigField() {
        var newField = {
          name: "",
          label: "",
          defaultValue: null,
          type: "text",
          isList: false
        };
        this.sharedData.newFlow.config.fields.push(newField);
      },

      removeConfigField(index) {
          this.sharedData.newFlow.config.fields.splice(index, 1);
      },

      addNewJobSpec() {
        var newJobSpec = {
          name: "",
          eventSource: "support",
          eventType: ""
        };
        this.sharedData.newFlow.jobSpecs.push(newJobSpec);
      },

      removeJobSpec(index) {
          this.sharedData.newFlow.jobSpecs.splice(index, 1);
      },

      addNewConnection() {
        var connection = {
          name: "",     
          defaultScopes: "",
          permissionScopes: "", 
          authUrl: "",
          tokenUrl: ""
        };
        this.sharedData.newFlow.connections.push(connection);
      },

      removeConnection(index) {
        this.sharedData.newFlow.connections.splice(index, 1);
      },

      // Load app initial data
      loadInitialData: async function (args) {

        try {

          //this.toggleLoader({ active: true});

          client.context().then(context => {
            this.sharedData.subdomain = context.account.subdomain;

            client.metadata().then(metadata => {
              this.sharedData.metadata = metadata;

              // If integration name not initialized -> Start at step #1 in the install flow
              //
              if (!metadata.settings.integration_name || metadata.settings.integration_name == '-') {
                this.sharedData.showIntegrationNameDialog = true;
                this.sharedData.suggestedIntegrationName = "zis_demo_" + this.sharedData.subdomain;
                this.sharedData.playgroundIntegrationName = "zis_playground_" + this.sharedData.subdomain;
                this.sharedData.integrationName = this.sharedData.suggestedIntegrationName; 
              } else {
                // Integration name initialized
                //
                this.sharedData.integrationName = metadata.settings.integration_name;

                // Read application config
                //
                loadConfig(this.sharedData.integrationName, "zis-workbench").then(result => {
                  this.sharedData.appConfig = result.configs[0];             
                  this.sharedData.useWithZisPlayground = this.sharedData.appConfig.config.useWithZisPlayground;
                  console.log("Use ZIS Playground: " + this.sharedData.useWithZisPlayground);

                  if (!this.sharedData.appConfig.config.zendeskConnectionInstalled) {
                    // Start at step #2 (if interrupted)
                    //
                    console.log("Zendesk connection not installed...");
                    this.sharedData.showZendeskConnectionDialog = true;
                  } else {
                    // App initialized -> Show flows & recipies
                    //
                    this.sharedData.showFlows = true;
                    console.log("Fetching available connections...")
                    getConnections(this.sharedData.integrationName).then(result => {
                      this.sharedData.connections = result.connections;
                      this.initFlows();   
                    });
                  }
                });
              }
            });

          });

        } catch (err) {
          // TODO: Will this catch work now with above promise?
          console.log(err);
          notifyErrorTemp(err);
        } finally {
          
        }

      },
  
      // Toggle app loader
      // Usage example: toggleLoader({ active: true, opacity: 1 })
      // Optional: opacity
      toggleLoader: function (args) {
        const active = args && args.active
        const opacity = args && args.opacity
  
        this.loader = {
          active: active,
          opacity: opacity || 0.7
        }
      },
  
    },
  
    /////////////////////////////////////////////////////////////////////////////
    // Watch
    /////////////////////////////////////////////////////////////////////////////
  
    watch: {
      
    },
  
    /////////////////////////////////////////////////////////////////////////////
    // Mounted
    /////////////////////////////////////////////////////////////////////////////
  
    mounted: function () {

      
    },
  
    /////////////////////////////////////////////////////////////////////////////
    // Created
    /////////////////////////////////////////////////////////////////////////////
  
    created: function () {
  
      // Load initial app data
      //
      this.loadInitialData()
    }
  })
  
// Highlight.JS
// 
Vue.use(hljsVuePlugin)