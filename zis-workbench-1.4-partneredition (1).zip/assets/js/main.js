// Initialise Apps framework client. See also:
// https://developer.zendesk.com/apps/docs/developer-guide/getting_started
const client = ZAFClient.init();

// Vuetify settings
const vuetify = new Vuetify({
  icons: {
    iconfont: "fa",
  },
  theme: {
    themes: {
      light: {
        //primary: "#EB702D",
        //secondary: "#009EDF",
        // TODO: Set button theme to blue and white text (to align to std Zendesk)
      },
    },
  },
});

// General functions
///////////////////////////////////////////////////////////////////////////////

function isEmpty(str) {
  return !str || str.length === 0;
}

function formatEventType(eventType) {
  const result = eventType
    .replace("ticket.", "")
    .replace("user.", "")
    .replace("organization.", "")
    .replace("customObject.", "")
    .replace("activity.", "")
    .replace(/([A-Z])/g, " $1");
  return result.charAt(0).toUpperCase() + result.slice(1);
}

function copyObjectArray(array) {
  var copy = [];
  for (const item of array) {
    copy.push(Object.assign({}, item));
  }
  return copy;
}

function capitalizeFirstLetter(string) {
  return string.charAt(0).toUpperCase() + string.slice(1);
}

function notifyTemp(message) {
    client.invoke('notify', message);
};

function notifyErrorTemp(message) {
  client.invoke('notify', message, 'error');
};

function notifySticky(message){
client.invoke('notify', message, 'error', {sticky: true});
};

function downloadFile(data, filename, mime, bom) {
  var blobData = (typeof bom !== 'undefined') ? [bom, data] : [data]
  var blob = new Blob(blobData, {type: mime || 'application/octet-stream'});
  if (typeof window.navigator.msSaveBlob !== 'undefined') {
      // IE workaround for "HTML7007: One or more blob URLs were
      // revoked by closing the blob for which they were created.
      // These URLs will no longer resolve as the data backing
      // the URL has been freed."
      window.navigator.msSaveBlob(blob, filename);
  }
  else {
      var blobURL = (window.URL && window.URL.createObjectURL) ? window.URL.createObjectURL(blob) : window.webkitURL.createObjectURL(blob);
      var tempLink = document.createElement('a');
      tempLink.style.display = 'none';
      tempLink.href = blobURL;
      tempLink.setAttribute('download', filename);

      // Safari thinks _blank anchor are pop ups. We only want to set _blank
      // target if the browser does not support the HTML5 download attribute.
      // This allows you to download files in desktop safari if pop up blocking
      // is enabled.
      if (typeof tempLink.download === 'undefined') {
          tempLink.setAttribute('target', '_blank');
      }

      document.body.appendChild(tempLink);
      tempLink.click();

      // Fixes "webkit blob resource error 1"
      setTimeout(function() {
          document.body.removeChild(tempLink);
          window.URL.revokeObjectURL(blobURL);
      }, 200)
  }
}

async function loadConfig(integrationName, scope) {
  return client.request({
    url: `/api/services/zis/integrations/${integrationName}/configs?filter[scope]=${scope}`,
  });
}

async function createConfig(integrationName, config) {
  return client.request({
    url: `/api/services/zis/integrations/${integrationName}/configs`,
    type: "POST",
    contentType: "application/json",
    data: JSON.stringify(config),
  });
}

async function updateConfig(integrationName, scope, config) {
  console.log("Updating config for scope: " + scope, config);
  return client.request({
    url: `/api/services/zis/integrations/${integrationName}/configs/${scope}`,
    type: "PUT",
    data: JSON.stringify(config),
  });
}

async function createIntegration(integrationName, description) {
  return client.request({
    url: `/api/services/zis/registry/${integrationName}`,
    type: "POST",
    contentType: "application/json",
    data: `{
                "description": "${description}"
            }`,
  });
}

async function installFlow(integrationName, flowDefinition) {
  return client.request({
    url: `/api/services/zis/registry/${integrationName}/bundles`,
    type: "POST",
    contentType: "application/json",
    data: flowDefinition,
  });
}

async function createInboundWebhook(integrationName, webhookDefinition, accessToken) {

    return client.request({
        url: `/api/services/zis/inbound_webhooks/generic/${integrationName}`,
        type: "POST",
        headers: {
          authorization: `Bearer ${accessToken}`,
        },
        contentType: "application/json",
        data: JSON.stringify(webhookDefinition)
    });
}

async function getInboundWebhook(integrationName, uuid, accessToken) {
    return client.request({
      url: `/api/services/zis/inbound_webhooks/generic/${integrationName}/${uuid}`,
      headers: {
        authorization: `Bearer ${accessToken}`
      }
  });
}

async function fireInboundWebhook(webhookUrl, username, password, payloadStr) {
    var authToken = btoa(username + ":" + password);
    return client.request({
      url: webhookUrl,
      type: "POST",
      headers: {
        authorization: `Basic ${authToken}`,
      },
      contentType: "application/json",
      data: payloadStr
    });
}

async function getConnections(integrationName) {
    return client.request({
        url: `/api/services/zis/integrations/${integrationName}/connections?named=true`,
        type: "GET"
    });
}

async function installJobSpec(integrationName, jobSpecName) {
  return client.request({
    url: `/api/services/zis/registry/job_specs/install?job_spec_name=zis:${integrationName}:job_spec:${jobSpecName}`,
    type: "POST",
  });
}

async function uninstallJobSpec(integrationName, jobSpecName) {
  console.log("Uninstall job spec: " + integrationName + "," + jobSpecName);
  return client.request({
    url: `/api/services/zis/registry/job_specs/install?job_spec_name=zis:${integrationName}:job_spec:${jobSpecName}`,
    type: "DELETE",
  });
}

function startOAuthFlow(integrationName, connectionName, clientName,
                        subdomain,permissionScopes, completeCallback, callbackArgs) {

  let data = JSON.stringify({
    name: connectionName,
    oauth_client_name: clientName,
    oauth_url_subdomain: subdomain,
    origin_oauth_redirect_url: window.location.href,
    permission_scopes: permissionScopes,
  });

  let request = {
    type: "POST",
    url: "/api/services/zis/connections/oauth/start/" + integrationName,
    contentType: "application/json",
    data: data,
  };

  client.request(request).then(
    function (response) {
      console.log("OAuth flow started. Response:", response);
      console.log("Authorizating using the following redirect URL: " + response.redirect_url);
      authorize(response.redirect_url, completeCallback, callbackArgs);
    },
    function (response) {
      console.log("Failed to start OAuth flow: ", response);
    }
  );
}

function authorize(redirectURL, completeCallback, callbackArgs) {
  let authWindow = window.open(redirectURL, "_blank");
  setTimeout(watchToken, 1500);
  // Poll token from the newly opened window
  //
  function watchToken() {
    try {
      let params = new URL(authWindow.location.href).searchParams;
      // Cross-origin access will cause an error.
      // When the OAuth flow completes, the authWindow's location
      // redirects back to the same origin.
      // This lets ZIS get the verification token.
      //
      let verificationToken = params.get("verification_token");
      console.log("Verification token: ", verificationToken);
      console.log("Established OAuth connection");
      authWindow.close();
      completeCallback(callbackArgs);
    } catch (err) {
      console.log("DOM error expected during cross domain authorization: " + err);
      setTimeout(watchToken, 500);
    }
  }
}

function errorResponse(response) {
  if (response?.responseJSON?.errors) {
    // returns validation errors when response contains responseJSON errors
    return {
      status: response.status,
      errors: response.responseJSON.errors,
    }
  } else if (response?.responseText) {
    // returns engine errors when response contains only responseText
    return {
      status: response.status,
      errors: [{ title: response.responseText }],
    }
  }

  return response
}

async function getZendeskAccessToken(integrationName) {

  return client.request({
    url: "/api/v2/oauth/clients.json",
    contentType: "application/json"
  }).then(result => {
    var oauthClient = result.clients.find(client => client.identifier === "zis_" + integrationName);
    if (oauthClient) {
      return client.request({
        type: "POST",
        url: "/api/v2/oauth/tokens.json",
        contentType: "application/json",
        data: JSON.stringify({
          token: {
            client_id: oauthClient.id,
            scopes: ["read", "write"]
          }
        })
      }).then(result => {
        return result.token.full_token;
      });
    }
  });
  
}

async function createOAuthClient(integrationName, connectionName, clientId,
                                 clientSecret, authUrl, tokenUrl, defaultScopes) {
  const request = {
    type: "POST",
    url: `/api/services/zis/connections/oauth/clients/${integrationName}`,
    contentType: "application/json",
    data: JSON.stringify({
      name: connectionName,
      client_id: clientId,
      client_secret: clientSecret,
      default_scopes: defaultScopes,
      auth_url: authUrl,
      token_url: tokenUrl
    }),
  };

  return client.request(request).then(
    (response) => {
      console.log("Oauth Client created successfully: ", response);
      return response;
    },
    (error) => {
      console.log("Failed to create oauth client: ", error);
      return error;
    }
  );
}

async function listInstalledApps() {
  return client.request({
    url: '/api/v2/apps/installations'
  });
}

async function updateAppSetting(appId, name, value) {
  
  console.log("Updating app setting for app ID: " + appId);
  listInstalledApps().then(apps => {

    let appInstallId = null;
    for (const app of apps.installations) {
      if (app.app_id == appId) {
        appInstallId = app.id;
      }
    }
    if (appInstallId) { 
      console.log("Updating setting '" + name + "': " + value);
      client.request({
        url: `/api/v2/apps/installations/${appInstallId}.json`,
        method: "PUT",
        contentType: 'application/json',
        data: `{
          "settings": {
            "${name}":"${value}"
          }
        }`
      });
    }

  });

}


