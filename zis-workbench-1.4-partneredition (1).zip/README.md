# ZIS Workbench

The ZIS Workbench provides the following functionality:

- Install/uninstall of flows
- Import & export of flows
- Configuration of flows
- Setup of different OAuth connections to Zendesk, Slack etc
- Setup of inbound webhooks needed by the flows
- Fire webhooks directly from the app
- Can be integrated with the ZIS Playground. This allows installed flows to be opened in the Playground with just one click. 
 
When the ZIS Playground integration is enabled will enable the following functionality:

- Create new flow from scratch and edit in ZIS Playground including setup of configuration fields, inbound webhooks, OAuth connections, job specifications etc 
- Get changes from ZIS playground and redeploy the flow
 
The ZIS Workbench comes with a set of different ZIS flows that you can install to showcase different types of ZIS use cases including automation (e.g redact tickets automatically), inbound integrations (e.g. Salesforce) and outbound integrations (e.g. Slack). 

This app is an unoffical and not supported app developed by the Platform Architect team at Zendesk. 